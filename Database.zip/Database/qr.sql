-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2025 at 05:14 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qr`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `item_id` int(11) NOT NULL,
  `item_category` varchar(50) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `day_of_week` varchar(10) NOT NULL,
  `item_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`item_id`, `item_category`, `item_name`, `price`, `day_of_week`, `item_image`) VALUES
(1, 'breakfast', 'Plain Dosa', 80.00, 'Monday', ''),
(2, 'breakfast', 'Vada', 40.00, 'Tuesday', ''),
(3, 'breakfast', 'Poha', 50.00, 'Wednesday', ''),
(4, 'breakfast', 'Tea', 20.00, 'Thursday', ''),
(5, 'breakfast', 'Sambar', 50.00, 'Friday', ''),
(6, 'breakfast', 'Milk', 30.00, 'Saturday', ''),
(7, 'breakfast', 'Chutney', 30.00, 'Sunday', ''),
(8, 'breakfast', 'Fafda-Jalebi', 60.00, 'Monday', ''),
(9, 'lunch', 'Chole-Puri', 80.00, 'Tuesday', ''),
(10, 'lunch', 'Roti', 20.00, 'Wednesday', ''),
(11, 'lunch', 'Curd', 20.00, 'Thursday', ''),
(12, 'lunch', 'Dal', 40.00, 'Friday', ''),
(13, 'lunch', 'Rice', 60.00, 'Saturday', ''),
(14, 'lunch', 'Pickle', 30.00, 'Sunday', ''),
(15, 'lunch', 'Gujarati Thali', 120.00, 'Monday', ''),
(16, 'lunch', 'Punjabi Thali', 150.00, 'Tuesday', ''),
(17, 'high tea', 'Milk', 30.00, 'Wednesday', ''),
(18, 'high tea', 'Tea', 20.00, 'Thursday', ''),
(19, 'high tea', 'Dabeli', 20.00, 'Friday', ''),
(20, 'high tea', 'Maggi', 40.00, 'Saturday', ''),
(21, 'high tea', 'Samosa', 50.00, 'Sunday', ''),
(22, 'high tea', 'Kachori', 20.00, 'Monday', ''),
(23, 'high tea', 'Vada Pav', 20.00, 'Tuesday', ''),
(24, 'high tea', 'Sandwich', 50.00, 'Wednesday', ''),
(25, 'dinner', 'Roti', 20.00, 'Thursday', ''),
(26, 'dinner', 'Rice', 60.00, 'Friday', ''),
(27, 'dinner', 'Pickle', 30.00, 'Saturday', ''),
(28, 'dinner', 'Baigan', 50.00, 'Sunday', ''),
(29, 'dinner', 'Buttermilk', 15.00, 'Monday', ''),
(30, 'dinner', 'Chutney', 20.00, 'Tuesday', ''),
(31, 'dinner', 'Dal', 40.00, 'Wednesday', ''),
(32, 'dinner', 'Papad', 10.00, 'Thursday', ''),
(33, 'breakfast', 'apple', 20.00, 'Monday', ''),
(34, 'lunch', 'salad', 30.00, 'Monday', ''),
(35, 'lunch', 'pasta', 30.00, 'Monday', ''),
(36, 'breakfast', 'toast', 20.00, 'Monday', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
