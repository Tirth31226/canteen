<?php
// Database connection
$host = 'localhost';  // Your database host (e.g., 'localhost')
$username = 'root';   // Your database username
$password = '';       // Your database password (empty by default for XAMPP)
$db_name = 'otp'; // Your database name

// Create a connection
$con = mysqli_connect($host, $username, $password, $db_name);

// Check if connection is successful
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
