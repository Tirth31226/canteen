<?php
session_start();
require 'connection.php'; // Database connection
require __DIR__ . '/phpmailer/src/Exception.php';  // PHPMailer files
require __DIR__ . '/phpmailer/src/PHPMailer.php';
require __DIR__ . '/phpmailer/src/SMTP.php';

// Use PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Initialize variables
$email = "";
$name = "";
$errors = array();

// If the user is trying to sign up
if (isset($_POST['signup'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

    if ($password !== $cpassword) {
        $errors['password'] = "Confirm password not matched!";
    }

    // Check if email exists for sign-up
    $email_check = "SELECT * FROM admin WHERE email = '$email'";
    $res = mysqli_query($con, $email_check);
    if (mysqli_num_rows($res) > 0) {
        $errors['email'] = "Email already exists!";
    }

    if (count($errors) === 0) {
        // Encrypt the password
        $encpass = password_hash($password, PASSWORD_BCRYPT);
        // Generate OTP code
        $code = rand(999999, 111111);
        $status = "notverified"; // Default status for new users

        // Insert user data into the database
        $insert_data = "INSERT INTO admin (name, email, password, code, status) 
                        VALUES('$name', '$email', '$encpass', '$code', '$status')";
        $data_check = mysqli_query($con, $insert_data);

        if ($data_check) {
            // Send email using PHPMailer
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'swaadcanteen@gmail.com'; // Your email address
                $mail->Password = 'xaod bbwx bksa wuwx'; // Your Gmail app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Recipients
                $mail->setFrom('swaadcanteen@gmail.com', 'Swaad Canteen');
                $mail->addAddress($email, $name);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Email Verification Code';
                $mail->Body    = "Your verification code is $code";
                $mail->AltBody = "Your verification code is $code";

                $mail->send();

                // Save the verification message in session
                $_SESSION['info'] = "We've sent a verification code to your email - $email";
                $_SESSION['email'] = $email;

                // Redirect to OTP page for the user to verify the code
                header('Location: user-otp.php'); // Redirect to OTP verification page
                exit();
            } catch (Exception $e) {
                $errors['otp-error'] = "Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            $errors['db-error'] = "Failed to insert data into database!";
        }
    }
}

// If the user is requesting password reset
if (isset($_POST['check-email'])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);

    // Check if the email exists in the database for password reset
    $email_check = "SELECT * FROM admin WHERE email = '$email'";
    $res = mysqli_query($con, $email_check);

    if (mysqli_num_rows($res) > 0) {
        // Email exists, generate OTP for password reset
        $otp = rand(100000, 999999); // Generate a random 6-digit OTP
        $_SESSION['otp'] = $otp; // Store OTP in session to verify later

        // Send OTP to the user's email using PHPMailer
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true; 
            $mail->Username = 'swaadcanteen@gmail.com'; // Your email address
            $mail->Password = 'xaod bbwx bksa wuwx'; // Your Gmail app password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('swaadcanteen@gmail.com', 'Swaad Canteen');
            $mail->addAddress($email);

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset OTP';
            $mail->Body    = "Your OTP for reset your password is <b>$otp</b>";
            $mail->AltBody = "Your OTP for reset your password is $otp";

            $mail->send();

            // Set a session message indicating OTP was sent
            $_SESSION['info'] = "We have sent an OTP to your email address.";
            header('Location: reset-code.php'); // Redirect to new password page
            exit();
        } catch (Exception $e) {
            $errors['otp-error'] = "Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        $errors['email'] = "No account found with that email address.";
    }
}
?>
