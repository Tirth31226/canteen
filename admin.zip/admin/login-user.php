<?php
require_once "controllerUserData.php"; // Include the controller to handle login logic

// Initialize an error array
$errors = array();

// Check if the form is submitted (when the login button is clicked)
if (isset($_POST['login'])) {
    // Fetch email and password from POST request
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    // Query to check if the email exists in the database
    $email_check = "SELECT * FROM admin WHERE email = '$email'";
    $result = mysqli_query($con, $email_check);

    // If email is found in the database
    if (mysqli_num_rows($result) > 0) {
        $user_data = mysqli_fetch_assoc($result);
        $db_password = $user_data['password']; // Fetch hashed password from DB

        // Verify the password entered by user with the stored hashed password
        if (password_verify($password, $db_password)) {
            // If credentials are correct, set cookies to store user login status
            setcookie("email", $email, time() + (86400 * 30), "/"); // Cookie expires in 30 days
            setcookie("name", $user_data['name'], time() + (86400 * 30), "/"); // Cookie for name

            // Redirect to home page after successful login
            header('Location: web/add_menu.html');
            exit(); // Exit to prevent further code execution after redirect
        } else {
            // If password does not match
            $errors[] = "Incorrect password!";
        }
    } else {
        // If email is not found in the database
        $errors[] = "This email is not registered!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: url('login 3.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
        }

        .login-container {
            background: rgba(0, 0, 0, 0.7);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
            width: 100%;
            max-width: 400px;
            color: white;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-control {
            border-radius: 5px;
        }

        .btn-primary {
            background: #FEA116;
            border: none;
            width: 100%;
            padding: 10px;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background: #e6950c;
        }

        .extra-links {
            text-align: center;
            margin-top: 15px;
        }

        .extra-links a {
            color: #FEA116;
            text-decoration: none;
        }

        .extra-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Admin Login</h2>
        
        <?php
        if (count($errors) > 0) {
            echo '<div class="alert alert-danger">';
            foreach ($errors as $showerror) {
                echo $showerror . "<br>";
            }
            echo '</div>';
        }
        ?>

        <form action="login-user.php" method="POST" autocomplete="off">
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="Email Address" required value="<?php echo isset($email) ? $email : ''; ?>">
            </div>
            
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>
            
            <button type="submit" name="login" class="btn btn-primary">Login</button>

            <!-- Sign-up Link -->
            <div class="link login-link text-center">Not yet a member? <a href="signup-user.php">Signup now</a></div>
            
            <div class="extra-links">
                <p><a href="forgot-password.php">Forgot password?</a></p>
            </div>
        </form>
    </div>
</body>
</html>
