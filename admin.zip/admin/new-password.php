<?php
require_once "controllerUserData.php"; // Database and session handling logic

// Initialize errors array for validation messages
$errors = [];

// Ensure the user is logged in by checking their session
$email = $_SESSION['email'];
if (!$email) {
    header('Location: login-user.php');
    exit();
}

// Handle the form submission
if (isset($_POST['change-password'])) {
    // Get password and confirm password from form
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

    // Validate the passwords
    if ($password !== $cpassword) {
        $errors[] = "Passwords do not match!";
    }

    if (strlen($password) < 8) {
        $errors[] = "Password should be at least 8 characters.";
    }

    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = "Password must contain at least one uppercase letter.";
    }

    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = "Password must contain at least one lowercase letter.";
    }

    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must contain at least one number.";
    }

    if (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $errors[] = "Password must contain at least one special character.";
    }

    // If no errors, update the password in the database
    if (count($errors) === 0) {
        // Encrypt the password
        $encpass = password_hash($password, PASSWORD_BCRYPT);

        // Update the password in the database for the user
        $update_query = "UPDATE admin SET password = '$encpass' WHERE email = '$email'";

        // If the password update query is successful, redirect the user
        if (mysqli_query($con, $update_query)) {
            $_SESSION['info'] = "Password has been updated successfully!";
            header('Location: login-user.php'); // Redirect to login page
            exit();
        } else {
            $errors[] = "Failed to update password in the database.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create a New Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style(new).css">
    
    <script>
        function validatePassword() {
            var password = document.getElementsByName("password")[0].value;
            var cpassword = document.getElementsByName("cpassword")[0].value;
            var feedback = document.getElementById("password-feedback");

            // Reset feedback
            feedback.innerHTML = "";
            
            var hasUpper = /[A-Z]/.test(password);
            var hasLower = /[a-z]/.test(password);
            var hasNumber = /[0-9]/.test(password);
            var hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

            var errorMessage = "";

            // Check if password length is less than 8 characters
            if (password.length < 8) {
                errorMessage += "Password must be at least 8 characters long.<br>";
            }

            // Check if passwords match
            if (password !== cpassword) {
                errorMessage += "Passwords do not match.<br>";
            }

            // Check for each condition
            if (!hasUpper) {
                feedback.innerHTML += "Password must contain at least one uppercase letter.<br>";
            }
            if (!hasLower) {
                feedback.innerHTML += "Password must contain at least one lowercase letter.<br>";
            }
            if (!hasNumber) {
                feedback.innerHTML += "Password must contain at least one number.<br>";
            }
            if (!hasSpecialChar) {
                feedback.innerHTML += "Password must contain at least one special character.<br>";
            }

            // If there's any error, show feedback and prevent form submission
            if (errorMessage || feedback.innerHTML) {
                alert("Please correct the errors.");
                return false;
            }

            return true;
        }

        function togglePasswordRequirements() {
            var requirements = document.getElementById("password-requirements");
            if (requirements.style.display === "none") {
                requirements.style.display = "block";
            } else {
                requirements.style.display = "none";
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 form">
                <form action="new-password.php" method="POST" autocomplete="off" onsubmit="return validatePassword()">
                    <h2 class="text-center">New Password</h2>

                    <!-- Display success or error message -->
                    <?php if (isset($_SESSION['info'])): ?>
                        <div class="alert alert-success text-center">
                            <?php echo $_SESSION['info']; ?>
                        </div>
                        <?php unset($_SESSION['info']); ?>
                    <?php endif; ?>

                    <?php if (count($errors) > 0): ?>
                        <div class="alert alert-danger text-center">
                            <?php foreach ($errors as $showerror): ?>
                                <?php echo $showerror; ?><br>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <!-- Password fields -->
                    <div class="form-group">
                        <input class="form-control" type="password" name="password" placeholder="Create new password" required>
                    </div>

                    <div class="form-group">
                        <input class="form-control" type="password" name="cpassword" placeholder="Confirm your password" required>
                    </div>

                    <!-- Password requirements info -->
                    <div class="form-group">
                        <span class="text-info" style="cursor: pointer;" onclick="togglePasswordRequirements()">ⓘ</span> 
                        <span>Password Requirements</span>
                        <div id="password-requirements" style="display: none; color: red; font-size: 12px;">
                            <ul>
                                <li>Password must be at least 8 characters long</li>
                                <li>Contain at least one uppercase letter</li>
                                <li>Contain at least one lowercase letter</li>
                                <li>Contain at least one number</li>
                                <li>Contain at least one special character (e.g., !@#$%^&*)</li>
                            </ul>
                        </div>
                    </div>

                    <div id="password-feedback" style="color: red;"></div>

                    <div class="form-group">
                        <input class="form-control button" type="submit" name="change-password" value="Change">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
