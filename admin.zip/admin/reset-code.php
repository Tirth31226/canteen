<?php
require_once "controllerUserData.php"; // Ensure this is correct for your code context

// Make sure the user is logged in and the session email exists
$email = $_SESSION['email'];
if ($email == false) {
    header('Location: login-user.php');
    exit(); // Important to ensure the script stops here
}

// Initialize error variable to store OTP-related errors (if any)
$errors = [];

if (isset($_POST['check-reset-otp'])) {
    // Retrieve the OTP entered by the user
    $enteredOtp = $_POST['otp'];

    // Check if the OTP entered matches the OTP stored in the session
    if ($enteredOtp == $_SESSION['otp']) {
        // OTP is correct, so proceed with redirecting to the new-password page
        $_SESSION['info'] = "OTP verified successfully! You can now create a new password.";
        header('Location: new-password.php'); // Redirect to the new password page
        exit(); // Make sure the script stops here after redirection
    } else {
        // OTP is incorrect, add error to the errors array
        $errors[] = "Incorrect OTP. Please try again.";
    }
}

?>

<!-- Your HTML content for the page goes here -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Code Verification</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style(reset-code).css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 form">
                <form action="reset-code.php" method="POST" autocomplete="off">
                    <h2 class="text-center">Code Verification</h2>
                    <?php 
                    // Display success message if OTP is verified successfully
                    if(isset($_SESSION['info'])){
                        ?>
                        <div class="alert alert-success text-center" style="padding: 0.4rem 0.4rem">
                            <?php echo $_SESSION['info']; ?>
                        </div>
                        <?php
                    }
                    ?>
                    <?php
                    // Display error messages
                    if(count($errors) > 0){
                        ?>
                        <div class="alert alert-danger text-center">
                            <?php
                            foreach($errors as $showerror){
                                echo $showerror;
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="form-group">
                        <input class="form-control" type="number" name="otp" placeholder="Enter code" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control button" type="submit" name="check-reset-otp" value="Submit">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
