<?php
require_once "controllerUserData.php";
// Initialize an array to hold any error messages
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['signup'])) {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    // Validate password length
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    }

    // Validate if passwords match
    if ($password !== $cpassword) {
        $errors[] = "Passwords do not match.";
    }

    // Check if password contains at least one uppercase letter, one lowercase letter, one number, and one special character
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = "Password must contain at least one uppercase letter.";
    }
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = "Password must contain at least one lowercase letter.";
    }
    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must contain at least one number.";
    }
    if (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $errors[] = "Password must contain at least one special character.";
    }

    // If no errors, proceed with the registration logic (e.g., store user in DB)
    if (count($errors) === 0) {
        // You can save the user to the database here after hashing the password (e.g., password_hash())
        // Example:
        // $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Simulate OTP page redirect after successful signup
        // Normally you'd send the OTP via email or SMS
        // For now, let's redirect to otp.php (assuming this is the OTP verification page)
        header("Location: user-otp.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style(registration user).css">
    
    <script>
        function validatePassword() {
            var password = document.getElementsByName("password")[0].value;
            var cpassword = document.getElementsByName("cpassword")[0].value;
            var feedback = document.getElementById("password-feedback");

            // Reset feedback
            feedback.innerHTML = "";
            
            var hasUpper = /[A-Z]/.test(password);
            var hasLower = /[a-z]/.test(password);
            var hasNumber = /[0-9]/.test(password);
            var hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

            var errorMessage = "";

            // Check if password length is less than 8 characters
            if (password.length < 8) {
                errorMessage += "Password must be at least 8 characters long.<br>";
            }

            // Check if passwords match
            if (password !== cpassword) {
                errorMessage += "Passwords do not match.<br>";
            }

            // Check for each condition
            if (!hasUpper) {
                feedback.innerHTML += "Password must contain at least one uppercase letter.<br>";
            }
            if (!hasLower) {
                feedback.innerHTML += "Password must contain at least one lowercase letter.<br>";
            }
            if (!hasNumber) {
                feedback.innerHTML += "Password must contain at least one number.<br>";
            }
            if (!hasSpecialChar) {
                feedback.innerHTML += "Password must contain at least one special character.<br>";
            }

            // If there's any error, show feedback and prevent form submission
            if (errorMessage || feedback.innerHTML) {
                alert("Please correct the errors.");
                return false;
            }

            return true;
        }

        function togglePasswordRequirements() {
            var requirements = document.getElementById("password-requirements");
            if (requirements.style.display === "none") {
                requirements.style.display = "block";
            } else {
                requirements.style.display = "none";
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 form login-form">
                <form action="" method="POST" onsubmit="return validatePassword()">
                    <h2 class="text-center">Sign Up</h2>
                    <p class="text-center">Create an account</p>

                    <?php
                    // Display errors if there are any
                    if (count($errors) > 0) {
                        echo '<div class="alert alert-danger text-center">';
                        foreach ($errors as $showerror) {
                            echo $showerror;
                        }
                        echo '</div>';
                    }
                    ?>

                    <div class="form-group">
                        <input class="form-control" type="text" name="name" placeholder="Full Name" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="email" name="email" placeholder="Email Address" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="password" placeholder="Password" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="cpassword" placeholder="Confirm Password" required>
                    </div>

                    <!-- Password requirements info -->
                    <div class="form-group">
                        <span class="text-info" style="cursor: pointer;" onclick="togglePasswordRequirements()">ⓘ</span> 
                        <span>Password Requirements</span>
                        <div id="password-requirements" style="display: none; color: red; font-size: 12px;">
                            <ul>
                                <li>Password must be at least 8 characters long</li>
                                <li>Contain at least one uppercase letter</li>
                                <li>Contain at least one lowercase letter</li>
                                <li>Contain at least one number</li>
                                <li>Contain at least one special character (e.g., !@#$%^&*)</li>
                            </ul>
                        </div>
                    </div>

                    <div id="password-feedback" style="color: red;"></div>

                    <div class="form-group">
                        <input class="form-control button" type="submit" name="signup" value="Sign Up">
                    </div>

                    <div class="link login-link text-center">Already a member? <a href="login-user.php">Login now</a></div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
