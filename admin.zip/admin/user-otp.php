<?php 
require_once "controllerUserData.php"; // Include controller for logic

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: login-user.php');
    exit(); // Exit after redirecting
}

// If OTP form is submitted
if (isset($_POST['check'])) {
    $otp = $_POST['otp'];  // Get the OTP entered by the user
    $email = $_SESSION['email'];

    // Logic for OTP verification
    $query = "SELECT * FROM admin WHERE email = '$email' AND code = '$otp' LIMIT 1";
    $result = mysqli_query($con, $query);
    
    // Check if OTP exists and is correct
    if (mysqli_num_rows($result) > 0) {
        // Update the status to "verified" in the database
        $update_query = "UPDATE admin SET status = 'verified' WHERE email = '$email'";
        mysqli_query($con, $update_query);

        // Redirect to the next page (e.g., user dashboard)
        header('Location: login-user.php');
        exit(); // Exit after redirecting
    } else {
        // If OTP is incorrect
        $errors['otp'] = "Invalid OTP. Please try again.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Code Verification</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style(user-otp).css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 form">
                <form action="user-otp.php" method="POST" autocomplete="off">
                    <h2 class="text-center">Code Verification</h2>

                    <?php 
                    // Show success message if available
                    if (isset($_SESSION['info'])) {
                        echo '<div class="alert alert-success text-center">' . $_SESSION['info'] . '</div>';
                    }
                    // Show errors if there are any
                    if (count($errors) > 0) {
                        echo '<div class="alert alert-danger text-center">';
                        foreach ($errors as $showerror) {
                            echo $showerror;
                        }
                        echo '</div>';
                    }
                    ?>

                    <div class="form-group">
                        <input class="form-control" type="number" name="otp" placeholder="Enter verification code" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control button" type="submit" name="check" value="Submit">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
