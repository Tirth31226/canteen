document.addEventListener('DOMContentLoaded', function () {
    loadMenuItems();
    updateItemNames(); // Update the item names initially

    const generateQRButton = document.getElementById('generateQR');
    generateQRButton.addEventListener('click', generateQRCode);

    const menuForm = document.getElementById('menuForm');
    menuForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent form from submitting the traditional way

        const formData = new FormData(menuForm);

        fetch('store_menu.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(responseText => {
            // Display success message after submission
            document.getElementById('successMessage').style.display = 'block';
            // Optionally, reset the form fields
            menuForm.reset();
            loadMenuItems(); // Reload menu items to show the new one
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });

    // Event listener for category change (to update item names)
    document.getElementById('item_category').addEventListener('change', updateItemNames);
});

// Function to update the item names based on selected category
function updateItemNames() {
    const category = document.getElementById('item_category').value;
    const itemNameSelect = document.getElementById('item_name');

    // Clear the existing options in item_name dropdown
    itemNameSelect.innerHTML = '';

    let options = [];

    // Set options for each category
    if (category === 'breakfast') {
        options = ['Apple', 'Mango', 'Toast', 'Omelette', 'Plain Dosa', 'Vada', 'Poha', 'Tea', 'Sambar', 'Milk', 'Chutney', 'Fafda-Jalebi'];
    } else if (category === 'lunch') {
        options = ['Salad', 'Pasta', 'Burger', 'Pizza', 'Chole-Puri', 'Roti', 'Curd', 'Dal', 'Rice', 'Pickle', 'Gujarati-Thali', 'Punjabi-Thali'];
    } else if (category === 'high tea') {
        options = ['Sandwich', 'Scones', 'Cake', 'Tea', 'Milk', 'Dabeli', 'Maggi', 'Samosa', 'Kachori', 'VadaPav'];
    } else if (category === 'dinner') {
        options = ['Pasta', 'Steak', 'Fish', 'Chickens', 'Roti', 'Rice', 'Pickle', 'Baigan', 'Buttermilk', 'Chutney', 'Dal', 'Papad'];
    }

    // Add options to the item_name dropdown
    options.forEach(function(item) {
        const option = document.createElement('option');
        option.value = item.toLowerCase();
        option.textContent = item;
        itemNameSelect.appendChild(option);
    });
}

// Fetch and load menu items into the table
function loadMenuItems() {
    fetch('fetch_menu.php')
        .then((response) => response.text())
        .then((data) => {
            const menuTableBody = document.getElementById('menuTableBody');
            menuTableBody.innerHTML = data;
        })
        .catch((error) => console.error('Error loading menu items:', error));
}

// Generate QR code for the menu
function generateQRCode() {
    fetch('fetch_menu.php?format=text')
        .then((response) => response.text())
        .then((menuText) => {
            if (menuText.trim() === '') {
                alert('No menu items available to generate a QR code.');
                return;
            }

            const qrContainer = document.getElementById('qrCode');
            qrContainer.innerHTML = ''; // Clear previous QR code

            const qrOptions = {
                width: 500,  // Set desired width
                height: 500  // Set desired height
            };

            QRCode.toCanvas(menuText, qrOptions, function (err, canvas) {
                if (err) throw err;
                qrContainer.appendChild(canvas);
            });
        })
        .catch((error) => console.error('Error generating QR code:', error));
}

