<?php
$servername = "localhost";
$username = "root";  // Change if using a different user
$password = "";  // Change if your MySQL has a password
$database = "reviews_system";

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
