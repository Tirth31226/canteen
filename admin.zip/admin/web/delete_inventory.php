<?php
// Include the database connection
include('includes/db_connection.php');

// Check if ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare the DELETE statement
    $sql = "DELETE FROM inventory WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    // Execute the query
    if ($stmt->execute()) {
        // After deletion, reset the auto-increment value
        $reset_sql = "ALTER TABLE inventory AUTO_INCREMENT = 1";  // This can be adjusted to reset to a specific value if needed
        $conn->query($reset_sql);

        echo "Record deleted successfully!";
        header("refresh:2;url=index.php"); // Redirect back to the main page after 2 seconds
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "No ID provided!";
}

// Close the database connection
$conn->close();
?>
