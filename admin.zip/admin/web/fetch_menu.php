<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qr";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$format = isset($_GET['format']) ? $_GET['format'] : 'html';

if ($format === 'text') {
    // Generate plain text (CSV-like format) for the QR code
    $sql = "SELECT * FROM menu_items";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $menuText = "Item ID, Day, Category, Item Name, Price\n";
        while ($row = $result->fetch_assoc()) {
            $menuText .= $row['item_id'] . ", " . ucfirst($row['day_of_week']) . ", " . ucfirst($row['item_category']) . ", " . $row['item_name'] . ", ₹" . $row['price'] . "\n";
        }
        echo $menuText;
    } else {
        echo "";
    }
} else {
    // Fetch all menu items and return them in HTML format
    $sql = "SELECT * FROM menu_items";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row['item_id'] . "</td>
                    <td>" . ucfirst($row['day_of_week']) . "</td>
                    <td>" . ucfirst($row['item_category']) . "</td>
                    <td>" . $row['item_name'] . "</td>
                    <td>₹" . $row['price'] . "</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No menu items found.</td></tr>";
    }
}

$conn->close();
?>
