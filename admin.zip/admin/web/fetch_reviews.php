<?php
include 'db_connect.php';

$sql = "SELECT name, rating, review FROM reviews WHERE status = 'approved' ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);

$reviews = [];
while ($row = mysqli_fetch_assoc($result)) {
    $reviews[] = $row;
}

echo json_encode($reviews);
?>
