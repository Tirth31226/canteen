<?php
// Include the database connection
include('includes/db_connection.php');

// Fetch data from the database
$sql = "SELECT * FROM inventory";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Canteen Inventory</title>
    <link rel="stylesheet" href="css/inventory.css">
    <script src="js/script.js" defer></script>
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="logo">
            <i class="fas fa-utensils"></i> Swaad Canteen
        </div>
        <ul class="nav-links">
            <li><a href="add_menu.html">Add Menu</a></li>
            <li><a href="waste.html">Food Waste Report</a></li>
            <li><a href="menu.php">Review</a></li>
            <li><a href="order_history.php">Order History</a></li>
            <li><a href="inventory.php">Inventory</a></li>
            <li><a href="admin_messages.php">User Messages</a></li>
        </ul>
    </nav>

    <h1>Canteen Inventory</h1>

    <!-- Form for adding new inventory records -->
    <form id="inventory-form" method="POST" action="process_inventory.php">
        <label for="date">Date:</label>
        <input type="date" id="date" name="date" required><br><br>

        <label for="category">Category:</label>
        <select id="category" name="category" required onchange="updateItemNames()">
            <option value="Beverage">Beverage</option>
            <option value="Snack">Snack</option>
            <option value="Frozen Food">Frozen Food</option>
            <option value="Dairy">Dairy</option>
            <option value="Fruit">Fruit</option>
        </select><br><br>

        <label for="item_name">Item Name:</label>
        <select id="item_name" name="item_name" required>
            <!-- This will be populated dynamically -->
        </select><br><br>

        <label for="purchase_qty">Purchase Qty (kg):</label>
        <input type="number" id="purchase_qty" name="purchase_qty" step="0.01" required><br><br>

        <label for="stock_on_hand">Stock on Hand (kg):</label>
        <input type="number" id="stock_on_hand" name="stock_on_hand" step="0.01" required><br><br>

        <label for="consumption_qty">Consumption Qty (kg):</label>
        <input type="number" id="consumption_qty" name="consumption_qty" step="0.01" required><br><br>

        <label for="expiry_date">Expiry Date:</label>
        <input type="date" id="expiry_date" name="expiry_date" required><br><br>

        <button type="submit">Submit</button>
    </form>

    <hr>

    <!-- Table to display the inventory records -->
    <h2>Inventory Records</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Category</th>
                <th>Item Name</th>
                <th>Purchase Qty (kg)</th>
                <th>Stock on Hand (kg)</th>
                <th>Consumption Qty (kg)</th>
                <th>Expiry Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                $counter = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $counter . "</td>";
                    echo "<td>" . $row['date'] . "</td>";
                    echo "<td>" . $row['category'] . "</td>";
                    echo "<td>" . $row['item_name'] . "</td>";
                    echo "<td>" . $row['purchase_qty'] . "</td>";
                    echo "<td>" . $row['stock_on_hand'] . "</td>";
                    echo "<td>" . $row['consumption_qty'] . "</td>";
                    echo "<td>" . $row['expiry_date'] . "</td>";
                    echo "<td><a href='update_inventory.php?id=" . $row['id'] . "'>Update</a> | 
                            <a href='delete_inventory.php?id=" . $row['id'] . "' onclick='return confirm(\"Are you sure?\")'>Delete</a></td>";
                    echo "</tr>";
                    $counter++;
                }
            } else {
                echo "<tr><td colspan='9'>No records found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

</body>
</html>

<?php
$conn->close();
?>
