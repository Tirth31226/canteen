// JavaScript to update item names based on selected category
function updateItemNames() {
    var category = document.getElementById('category').value;
    var itemNameDropdown = document.getElementById('item_name');
    itemNameDropdown.innerHTML = ""; // Clear previous item names

    var items = [];

    // Define items based on category selection
    if (category === "Beverage") {
        items = ["Coffee (Instant)", "Tea Bags", "Juice"];
    } else if (category === "Snack") {
        items = ["Chips (Potato)", "Biscuits", "Popcorn"];
    } else if (category === "Frozen Food") {
        items = ["Frozen Pizza", "Frozen Vegetables", "Ice Cream"];
    } else if (category === "Dairy") {
        items = ["Milk", "Cheese", "Yogurt"];
    } else if (category === "Fruit") {
        items = ["Apples", "Bananas", "Oranges"];
    }

    // Populate item names based on selected category
    items.forEach(function(item) {
        var option = document.createElement("option");
        option.value = item;
        option.textContent = item;
        itemNameDropdown.appendChild(option);
    });
}
