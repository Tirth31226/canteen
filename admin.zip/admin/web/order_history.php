<?php
$servername = "localhost";
$username = "root"; // Change as per your DB credentials
$password = "";
$dbname = "payment";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM payment_history ORDER BY timestamp DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="order_history.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="logo">
            <i class="fas fa-utensils"></i> Swaad Canteen
        </div>
        <ul class="nav-links">
            <li><a href="add_menu.html">Add Menu</a></li>
            <li><a href="waste.html">Food Waste Report</a></li>
            <li><a href="order_history.php">Order History</a></li>
            <li><a href="inventory.php">Inventory</a></li>
            <li><a href="admin_messages.php">User Messages</a></li>
        </ul>
    </nav>
    
    <div class="container mt-5">
        <h2 class="mb-4">Order History</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Item Name</th>
                    <th>Amount (₹)</th>
                    <th>Payment Status</th>
                    <th>Timestamp</th>
                    <th>User Email</th> <!-- Added Email Column -->
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['order_id']}</td>
                                <td>{$row['item_name']}</td>
                                <td>{$row['amount']}</td>
                                <td>{$row['payment_status']}</td>
                                <td>{$row['timestamp']}</td>
                                <td>{$row['user_email']}</td> <!-- Display Email -->
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No payment records found</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
