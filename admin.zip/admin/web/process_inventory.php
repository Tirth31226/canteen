<?php
// Include the database connection
include('includes/db_connection.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $date = $_POST['date'];
    $category = $_POST['category'];
    $item_name = $_POST['item_name'];
    $purchase_qty = $_POST['purchase_qty'];
    $stock_on_hand = $_POST['stock_on_hand'];
    $consumption_qty = $_POST['consumption_qty'];
    $expiry_date = $_POST['expiry_date'];

    // Insert query to add new inventory record
    $sql = "INSERT INTO inventory (date, category, item_name, purchase_qty, stock_on_hand, consumption_qty, expiry_date) 
            VALUES ('$date', '$category', '$item_name', '$purchase_qty', '$stock_on_hand', '$consumption_qty', '$expiry_date')";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to index.php after successful insertion
        header("Location: index.php");
        exit();  // Ensure the rest of the script doesn't execute
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
