-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2025 at 03:00 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payment`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment_history`
--

CREATE TABLE `payment_history` (
  `id` int(11) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_history`
--

INSERT INTO `payment_history` (`id`, `order_id`, `item_name`, `amount`, `payment_status`, `timestamp`) VALUES
(1, 1740667315188, 'Medu-vada', 40.00, 'Success', '2025-02-27 14:41:55'),
(2, 1740667339770, 'Plain Dosa', 80.00, 'Success', '2025-02-27 14:42:19'),
(3, 1740667339770, 'Tea', 20.00, 'Success', '2025-02-27 14:42:19'),
(4, 1740667635221, 'Fafda-Jalebi', 60.00, 'Success', '2025-02-27 14:47:15'),
(5, 1740667995188, 'Coconut-chutney', 30.00, 'Success', '2025-02-27 14:53:15'),
(6, 1740668075493, 'Poha', 50.00, 'Success', '2025-02-27 14:54:35'),
(7, 1740669846926, 'Roti', 20.00, 'Success', '2025-02-27 15:24:06'),
(8, 1740669846926, 'Rice', 60.00, 'Success', '2025-02-27 15:24:06'),
(9, 1740669846926, 'Baigan Curry', 50.00, 'Success', '2025-02-27 15:24:06'),
(10, 1740669846926, 'Onion Lemon Pickle', 30.00, 'Success', '2025-02-27 15:24:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment_history`
--
ALTER TABLE `payment_history`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payment_history`
--
ALTER TABLE `payment_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
