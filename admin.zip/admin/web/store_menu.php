<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qr";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_category = $_POST['item_category'];
    $item_name = $_POST['item_name']; // Using the item name from the dropdown
    $price = $_POST['price'];
    $day_of_week = $_POST['day_of_week'];

    // Prepare SQL query to insert data
    $sql = "INSERT INTO menu_items (item_category, item_name, price, day_of_week) 
            VALUES ('$item_category', '$item_name', '$price', '$day_of_week')";

    if ($conn->query($sql) === TRUE) {
        echo "Menu item added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
