<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['date'];
    $meal_type = $_POST['meal_type'];
    $food_item = $_POST['food_item'];
    $prepared_qty = $_POST['prepared_qty'];
    $wasted_qty = $_POST['wasted_qty'];
    $reason_for_waste = $_POST['reason_for_waste'];
    $disposal_method = $_POST['disposal_method'];

    $sql = "INSERT INTO waste_data (date, meal_type, food_item, prepared_qty, wasted_qty, reason_for_waste, disposal_method) 
            VALUES ('$date', '$meal_type', '$food_item', '$prepared_qty', '$wasted_qty', '$reason_for_waste', '$disposal_method')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
    header('Location: waste.html'); // Redirect to the form page
    exit();
}
?>
