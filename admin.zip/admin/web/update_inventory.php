<?php
// Include the database connection
include('includes/db_connection.php');

// Check if ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the record from the database
    $sql = "SELECT * FROM inventory WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the record is found
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Record not found!";
        exit;
    }
} else {
    echo "No ID provided!";
    exit;
}

// If the form is submitted, process the update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the updated data from the form
    $date = $_POST['date'];
    $item_name = $_POST['item_name'];
    $category = $_POST['category'];
    $purchase_qty = $_POST['purchase_qty'];
    $stock_on_hand = $_POST['stock_on_hand'];
    $consumption_qty = $_POST['consumption_qty'];
    $expiry_date = $_POST['expiry_date'];

    // Prepare the SQL update statement
    $sql = "UPDATE inventory SET date=?, item_name=?, category=?, purchase_qty=?, stock_on_hand=?, consumption_qty=?, expiry_date=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssdsssi", $date, $item_name, $category, $purchase_qty, $stock_on_hand, $consumption_qty, $expiry_date, $id);

    // Execute the query
    if ($stmt->execute()) {
        echo "Record updated successfully!";
        header("refresh:2;url=index.php"); // Redirect back to the main page after 2 seconds
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Inventory</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <h1>Update Inventory Record</h1>

    <!-- Form for updating inventory records -->
    <form method="POST">
        <label for="date">Date:</label>
        <input type="date" id="date" name="date" value="<?php echo $row['date']; ?>" required><br><br>

        <label for="category">Category:</label>
        <select id="category" name="category" required>
            <option value="Beverage" <?php if ($row['category'] == "Beverage") echo "selected"; ?>>Beverage</option>
            <option value="Snack" <?php if ($row['category'] == "Snack") echo "selected"; ?>>Snack</option>
            <option value="Frozen Food" <?php if ($row['category'] == "Frozen Food") echo "selected"; ?>>Frozen Food</option>
            <option value="Dairy" <?php if ($row['category'] == "Dairy") echo "selected"; ?>>Dairy</option>
            <option value="Fruit" <?php if ($row['category'] == "Fruit") echo "selected"; ?>>Fruit</option>
        </select><br><br>

        <label for="item_name">Item Name:</label>
        <input type="text" id="item_name" name="item_name" value="<?php echo $row['item_name']; ?>" required><br><br>

        <label for="purchase_qty">Purchase Qty (kg):</label>
        <input type="number" id="purchase_qty" name="purchase_qty" step="0.01" value="<?php echo $row['purchase_qty']; ?>" required><br><br>

        <label for="stock_on_hand">Stock on Hand (kg):</label>
        <input type="number" id="stock_on_hand" name="stock_on_hand" step="0.01" value="<?php echo $row['stock_on_hand']; ?>" required><br><br>

        <label for="consumption_qty">Consumption Qty (kg):</label>
        <input type="number" id="consumption_qty" name="consumption_qty" step="0.01" value="<?php echo $row['consumption_qty']; ?>" required><br><br>

        <label for="expiry_date">Expiry Date:</label>
        <input type="date" id="expiry_date" name="expiry_date" value="<?php echo $row['expiry_date']; ?>" required><br><br>

        <button type="submit">Update</button>
    </form>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
