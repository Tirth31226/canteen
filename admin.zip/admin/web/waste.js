document.addEventListener("DOMContentLoaded", function () {
    fetchWasteData(); // Load data from database

    document.getElementById("generateReportBtn").addEventListener("click", function () {
        generatePDF();
    });
});
console.log(typeof jsPDF);
console.log(typeof window.jspdf.jsPDF);
console.log(typeof window.jspdf.autoTable);

// Fetch and display data
function fetchWasteData() {
    fetch("get_data.php")
        .then((response) => response.json())
        .then((data) => {
            let wasteDataContainer = document.getElementById("wasteData");
            wasteDataContainer.innerHTML = "";

            if (data.length === 0) {
                wasteDataContainer.innerHTML = "<p>No data available.</p>";
                return;
            }

            let table = document.createElement("table");
            table.setAttribute("border", "1");
            table.style.width = "100%";
            table.style.borderCollapse = "collapse";

            let thead = document.createElement("thead");
            let headerRow = document.createElement("tr");
            headerRow.innerHTML = `
                <th>Date</th>
                <th>Meal Type</th>
                <th>Food Item</th>
                <th>Prepared Qty (kg)</th>
                <th>Wasted Qty (kg)</th>
                <th>Reason for Waste</th>
                <th>Disposal Method</th>
            `;
            thead.appendChild(headerRow);
            table.appendChild(thead);

            let tbody = document.createElement("tbody");
            data.forEach((row) => {
                let rowElement = document.createElement("tr");
                rowElement.innerHTML = `
                    <td>${row.date}</td>
                    <td>${row.meal_type}</td>
                    <td>${row.food_item}</td>
                    <td>${row.prepared_qty}</td>
                    <td>${row.wasted_qty}</td>
                    <td>${row.reason_for_waste}</td>
                    <td>${row.disposal_method}</td>
                `;
                tbody.appendChild(rowElement);
            });

            table.appendChild(tbody);
            wasteDataContainer.appendChild(table);

            createChart(data);
        })
        .catch((error) => console.error("Error fetching data:", error));
}

// Create a chart
function createChart(data) {
    let ctx = document.getElementById("foodItemChart").getContext("2d");

    let labels = [...new Set(data.map((row) => row.food_item))];
    let wastedQuantities = labels.map(
        (item) => data.filter((row) => row.food_item === item)
            .reduce((sum, row) => sum + parseFloat(row.wasted_qty), 0)
    );

    new Chart(ctx, {
        type: "bar",
        data: {
            labels: labels,
            datasets: [{
                label: "Wasted Quantity (kg)",
                data: wastedQuantities,
                backgroundColor: "rgba(255, 99, 132, 0.6)",
                borderColor: "rgba(255, 99, 132, 1)",
                borderWidth: 1,
            }],
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                },
            },
        },
    });
}

// Generate PDF
function generatePDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.setFontSize(18);
    doc.text("Food Waste Report", 10, 10);

    let canvas = document.getElementById("foodItemChart");
    if (!canvas) {
        alert("Chart is missing!");
        return;
    }

    setTimeout(() => {
        let chartImage = canvas.toDataURL("image/png");
        doc.addImage(chartImage, "PNG", 10, 20, 180, 80);

        let table = document.querySelector("table");
        if (!table) {
            alert("No table data found!");
            return;
        }

        let tableRows = [];
        let tableHeaders = [];

        table.querySelectorAll("tr").forEach((row, index) => {
            let rowData = [];
            row.querySelectorAll("th, td").forEach((cell) => {
                rowData.push(cell.textContent.trim());
            });

            if (index === 0) {
                tableHeaders = rowData;
            } else {
                tableRows.push(rowData);
            }
        });

        doc.autoTable({
            head: [tableHeaders],
            body: tableRows,
            startY: 110,
            theme: "striped",
        });

        doc.save("food_waste_report.pdf");
    }, 500); // Ensures the chart is fully loaded before saving
}
